Student = [("Ali", 80),("Ahmed", 87),("Aiman", 92),("Mishal", 98),("Rohan", 91)]

sortList = sorted(Student, key=lambda x: x[1], reverse = True)
print(sortList)

print(Student)
Top3 = sortList[:3]
print("\nTop 3 Stdents Are:")
print(Top3)