def closestToZero(pairs):
    minSum = min(abs(sum(p)) for p in pairs)
    return [p for p in pairs if abs(sum(p)) == minSum]

tuples = [(1,7),(2,5),(1,4),(2,0),(1,1),(1,4)]
pairs = closestToZero(tuples)
print("Pairs closest to zero sum:", pairs)
print("Sum:", sum(pairs[0]))
