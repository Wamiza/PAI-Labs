Password = input("Enter Your Password")

has_digit = False
has_letter = False
has_char = False
char = ("@", "#", "$", "%")

if len(Password) >= 8:
    if Password.isdigit():
        has_digit = True
    elif Password.isalpha():
        has_letter = True
    elif char in Password:
        has_char = True


if has_digit and has_char and has_letter:
    print("Valid Password")
else:
    print("Invalid Password, must have atleast 8 characters, both digits and letters, and a special character ")