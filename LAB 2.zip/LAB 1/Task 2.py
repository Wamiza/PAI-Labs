A = [[1,2,3], [4,5,6]]
B = [[1,2,3], [4,5,6]]

C = [[0 for _ in range(len(A[0]))] for _ in range(len(A))]

for i in range(len(A)):           
    for j in range(len(A[0])):    
        C[i][j] = A[i][j] + B[i][j]
print("Matrix Addition: ")
print(C)

D = [[1, 2, 3],[4, 5, 6]]

E = [[1, 2],[3, 4],[5, 6]]

rows_D = len(D)
cols_D = len(D[0])
rows_E = len(E)
cols_E = len(E[0])

F = [[0 for _ in range(cols_E)] for _ in range(rows_D)]

for i in range(rows_D):
    for j in range(cols_E):
        for k in range(cols_D):   
            F[i][j] += D[i][k] * E[k][j]

print("Matrix Multiplication:")
print(F)