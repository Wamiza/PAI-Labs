students = {}

students["Ali"] = 85
students["Ayesha"] = 92
students["Omar"] = 78

students["Ali"] = 90
del students["Omar"]

topper = max(students, key=students.get)

print("Topper:", topper, "with", students[topper])
print("All students:", students)