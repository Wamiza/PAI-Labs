Country = {}
Country["Pakistan"] = 255 
Country["India"] = 1450
Country["China"] = 1419
Country["Rusia"] = 144

top3 = []

for _ in range(3):
    maxCountry = None
    maxPopulation = -1
    for c, p in Country.items():
        if p > maxPopulation and c not in top3:
            maxPopulation = p
            maxCountry = c
    top3.append(maxCountry)

print("Top 3 most populated countries:")
for c in top3:
    print(c, ":", Country[c])